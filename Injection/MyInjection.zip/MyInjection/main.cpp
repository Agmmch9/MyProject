#include "main.h"
int main(int argc, char* argv[]) {
	int nNum = atoi(argv[1]);
	MemoryThreadInjectDll(nNum, argv[2]);
	return 0;
}
