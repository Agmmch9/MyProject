﻿// dllmain.cpp : 定义 DLL 应用程序的入口点。
#include "pch.h"
HWND hWndOutlook1;
WNDPROC oldWndProc = 0;
DWORD nTarget = 0;
LRESULT CALLBACK NewWndProc(HWND hWnd, UINT uMsg, WPARAM wParam, LPARAM lParam) {

    if (uMsg == WM_MOUSEMOVE) {


		int x = LOWORD(lParam); //客户区的Y坐标  取低16位
		int y = HIWORD(lParam); //客户区的Y坐标  取高16位
		//通过坐标来计算点击的是哪个方格
		x = x + 4;
		x = x >> 4;
		y = y - 0x27;
		y = y >> 4;
		y = y * 32;
		nTarget = y + x + 0x1005340;
		
		//雷改变窗口标题
		if(*(PBYTE)nTarget == 0x8f)
		{
			SetWindowText(hWnd, "扫雪");
		}
		else {
			SetWindowText(hWnd, "扫雷");
		}
    
    }

    return CallWindowProc(oldWndProc, hWnd, uMsg, wParam, lParam);
}

BOOL APIENTRY DllMain( HMODULE hModule,
                       DWORD  ul_reason_for_call,
                       LPVOID lpReserved
                     )
{
    switch (ul_reason_for_call)
    {
    case DLL_PROCESS_ATTACH:

		hWndOutlook1 = ::FindWindow("扫雷", "扫雷");
		oldWndProc = (WNDPROC)GetWindowLongPtr(hWndOutlook1, GWLP_WNDPROC); //需要恢复的消息函数
		(WNDPROC)SetWindowLong(hWndOutlook1, GWL_WNDPROC, (LONG)NewWndProc);
        break;
    case DLL_THREAD_ATTACH:

    case DLL_THREAD_DETACH:
    case DLL_PROCESS_DETACH:
        break;
    }
    return TRUE;
}

